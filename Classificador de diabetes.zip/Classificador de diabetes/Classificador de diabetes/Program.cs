﻿using System;
using Classificador_de_diabetesML.Model;

namespace Classificador_de_diabetes
{
    class Program
    {
        static void Main(string[] args)
        {
            // Add input data
            var input = new ModelInput();

            // Load model and predict output of sample data
            ModelOutput result = ConsumeModel.Predict(input);

            Console.WriteLine(result.Prediction);
        }
    }
}
